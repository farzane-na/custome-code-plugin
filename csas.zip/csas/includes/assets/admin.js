jQuery(document).ready(function($){
    wp.codeEditor.initialize($('.code.js'));
    wp.codeEditor.initialize($('.code.css'));
})
